import re
from collections import defaultdict, Counter
word_list = []
key = '[a-z]+'
#def word_list():
words = open("novel.txt","r")
for line in words:
    line = line.strip().split(" ")
    for word in line:
        word = word.lower()
        words = re.findall(key, word)
        word_list.append(words)
#print(word_list)

#gets all the words
allwords = open("allwords.txt", "w")
for word in word_list:
    for char in word:
        w = allwords.write(char + "\n")
allwords.close()

# finds unique words
unique_words = open("uniquewords.txt", "w")
counter = defaultdict(int)
for words in word_list:
    for word in words:
        counter[word] += 1
        if counter[word] == 1:
            w = unique_words.write(word + "\n")
unique_words.close()

#finds word frequencies
frequencies = open("wordfrequency.txt", "w")
word_frequency = defaultdict(int)
loops = 0
frequency = 0
x = 0
while x < 521:
    for key in counter:
        if counter[key] == loops:
            frequency += 1
    word_frequency[loops] = frequency
    loops += 1
    frequency = 0
    x += 1
for word in word_frequency:
    frequencies.write(str(word) + ":" + str(word_frequency[word]) + "\n")
frequencies.close()

open the python script and check to make sure the allwords.txt, uniquewords.txt and wordfrequency.txt files are in the same folder.

For the A3_novelvisualization.pde file, make sure the uniquewords.txt file is in the same folder and press play 

Open rrm2738_assignment2.pde and make sure assignment2_image.jpg is in the data folder. hit play and the image will appear. use keys 1-4 to apply filters and 0 to return the image to normal. 

To run the animation, make sure the group_2_assignment4.pde, arbit_speed.pde and comet.pde are all in the same folder with a data folder.

simply press play to start the animation.
